import { Comment } from './../../node_modules/@types/estree/index.d';
import { Routes } from '@angular/router';
import { ErrorPageComponent } from './shared/error-page/error-page.component';
import { audit } from 'rxjs';
import { LoginComponent } from './auth/pages/login/login.component';
import { RegistroComponent } from './auth/pages/registro/registro.component';
import { ListadoComponent } from './heroes/pages/listado/listado.component';
import { AgregarComponent } from './heroes/pages/agregar/agregar.component';
import { BuscarComponent } from './heroes/pages/buscar/buscar.component';
import { HeroeComponent } from './heroes/pages/heroe/heroe.component';
import { HomeComponent } from './heroes/pages/home/home.component';

export const routes: Routes = [
  {
    path: 'auth',
    children: [
      // se usa children para anidar rutas, es decir la ruta seria /auth/login
      { path: 'login', component: LoginComponent },
      { path: 'registro', component: RegistroComponent },
      { path: '**', redirectTo: 'login' }, //redirige a login si no se encuentra la ruta
      //el path '**' es un comodin que se activa cuando no se encuentra la ruta,
      //es muy util para redirigir a una pagina de error, si el path no esta definido
    ],
  },
  {
    path: 'heroes',
    component: HomeComponent,
    children: [
      { path: 'listado', component: ListadoComponent },
      {path: 'agregar',component: AgregarComponent},
      {path: 'editar/:id',component: AgregarComponent},
      {path: 'buscar',component: BuscarComponent},
      {path: 'id',component: HeroeComponent},
      { path: '**', redirectTo: 'listado' },

]
  },

  { path: '404', component: ErrorPageComponent },
  { path: '**', redirectTo: '404' },
];
